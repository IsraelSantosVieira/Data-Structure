/*
 * Trabalho Final de Estrutura de Dados
 * 
 * Por: Israel Santos Vieira(201820268)
 *      Gustavo Costa Daguer(201910924)
 *      Mateus de Oliveira Peternelli(201820283) 
 * UFLA - 2019/2
 *
 * Implementação de funções da tabela Hash, ao decorrer de cada
 * função, encontra-se a descrição da mesma.
 * 
 */

#include "tabelahash.h"
#include "noh.h"
#include "Streaming.h"
typedef int Dado;
using namespace std;

// Função que calcula a posição do jogador na tabela
int funcaoHash(int chave, int capacity) {
  int h = 0;
  h = chave % capacity;
  return h;
}

// Cálculo da Preciosidade
int tabelaHash::funcaoPreciosidade(Dado habilidadeJogador, Dado idadeJogador){
  int precious = habilidadeJogador * 200 - idadeJogador * 5;
  return precious;  
}

// Construtor
tabelaHash::tabelaHash(int cap) {
  jogadores = new noh*[cap];
  capacidade = cap;
  tamanho = 0;
  for (int i = 0; i < cap; i++)
  jogadores[i] = nullptr;
}

// Destrutor
tabelaHash::~tabelaHash() {
  for (int i=0; i < capacidade; i++) {
  noh* atual = jogadores[i];
  // percorre a lista removendo todos os nÃ³s
  while (atual != nullptr) {
    noh* aux = atual;
    atual = atual-> proximo;
    delete aux;
  }
  }
  delete[] jogadores;
}

// Inserção de dados do jogador com os seguintes atributos:
// número da camisa, habilidade, idade e cálculo da preciosidade.
void tabelaHash::insere(Dado chave, Dado habilidadeJogador, Dado idadeJogador, Dado precioso) {
  noh* novoValor = new noh(chave, habilidadeJogador, idadeJogador, precioso);
  int posicao = funcaoHash(chave, capacidade);
  if(cheia()){
    Serial.println();
    Serial.println("Tabela de Jogadores Cheia!");
  }
  else{
  if(existe(chave) == false) {
    //inserção em hash
    if(jogadores[posicao] == nullptr){
    jogadores[posicao] = novoValor;
    }
    //inserção em hash > lista
    else{
    noh* i = jogadores[posicao];
    while (i->proximo != nullptr) {
      i = i->proximo;
    }
    i->proximo = novoValor;
    }
    tamanho++;
  }
  else{
    Serial.println("Esse jogador já foi registrado!");
  }
  }
}

// Verifica se o número da camisa é existente no time
bool tabelaHash::existe(Dado chave) {
  int h;
  h = funcaoHash(chave, capacidade);

  if ((jogadores[h] != nullptr) and (jogadores[h]->numeroCamisa == chave)) {
    return true;
  } else {
    noh* atual = jogadores[h];
  
    while ((atual != nullptr) and (atual->numeroCamisa != chave)) {
      atual = atual->proximo;
    }

    if ((atual != nullptr) and (atual->numeroCamisa == chave)) {
      return true; //já existe um jogador com essa camisa
    } else {
      return false; //não há jogador com essa camisa  
    }
  }
}

// Retira um jogador de acordo com o número da camisa
void tabelaHash::remover(Dado chave) {
  if (existe(chave)) {
    int h = funcaoHash(chave, capacidade);
    if (jogadores[h] != nullptr && jogadores[h]->numeroCamisa == chave) {
      noh* removido = jogadores[h];
      jogadores[h] = jogadores[h]->proximo;
      delete removido;
    } else {
      noh* atual = jogadores[h];
      noh* anterior;
      while (atual != nullptr && atual->numeroCamisa != chave) {
        anterior = atual;
        atual = atual->proximo;
      }
      if (atual != nullptr && atual->numeroCamisa == chave) {
        noh* removido = atual;
        anterior->proximo = atual->proximo;
        delete removido;
      }
    }
    tamanho--;
  }
}

// Função de Busca da Preciosidade, para fins de debugar
// a função serve também para imprimir todos os dados do
// jogador
void tabelaHash::busca(Dado chave) {
  int h = funcaoHash(chave, capacidade);
  if(jogadores[h] == nullptr){
    Serial.println();
    Serial.println("Jogador nao existe!");
    }
    else if(jogadores[h]->numeroCamisa == chave){
    Serial.println();
    Serial.print("Preciosidade: ");
    Serial.println(jogadores[h]->preciosidade);
    Serial.print("Idade: ");
    Serial.println(jogadores[h]->idade);
    Serial.print("Habilidade: ");
    Serial.println(jogadores[h]->habilidade);
  } 
  else{
    noh* atual = jogadores[h];
    while ((atual != nullptr) and (atual->numeroCamisa != chave)) {
      atual = atual->proximo;
    }
    if((atual != nullptr) and (atual->numeroCamisa == chave)) {
      Serial.println();
      Serial.print("Preciosidade: ");
      Serial.println(jogadores[h]->preciosidade);
      Serial.print("Idade: ");
      Serial.println(jogadores[h]->idade);
      Serial.print("Habilidade: ");
      Serial.println(jogadores[h]->habilidade);
    }
    else{
      Serial.println();
      Serial.println("Jogador nao existe!");
    }
  }
}

// Percorre a Tabela Hash dos jogadores, escrevendo
// as listas de itens (para fins de debug)
void tabelaHash::percorre() {
  noh* atual;
  for (int i = 0; i < capacidade; i++) {
  Serial.print(i); Serial.print(":");
  atual = jogadores[i];
  while (atual != nullptr) {
    Serial.print("[");
    Serial.print(atual->numeroCamisa);
    Serial.print("/");
    Serial.print(atual->habilidade);
    Serial.print("/");
    Serial.print(atual->idade);
    Serial.print("/");
    Serial.print(atual->preciosidade);
    Serial.print("]->");
    atual = atual->proximo;
  }
  Serial.println("VAZIO");
  }
  Serial.println();
  Serial.print("Quantidade de Jogadores: ");
  Serial.print(tamanho);
  Serial.println();
}

inline bool tabelaHash::cheia(){
  return (tamanho == capacidade);
}

int tabelaHash::meuTamanho(){
  return tamanho;  
}

Dado tabelaHash::myPrecious(Dado chave) {
  int h = funcaoHash(chave, capacidade);
  if(jogadores[h] == nullptr){
      return 0;
    }
    else if(jogadores[h]->numeroCamisa == chave){
    
    return jogadores[h]->preciosidade;
  } 
  else{
    noh* atual = jogadores[h];
    while ((atual != nullptr) and (atual->numeroCamisa != chave)) {
      atual = atual->proximo;
    }
    if((atual != nullptr) and (atual->numeroCamisa == chave)) {
      return jogadores[h]->preciosidade;
    }
    else{
      return 0;
    }
  }
}
