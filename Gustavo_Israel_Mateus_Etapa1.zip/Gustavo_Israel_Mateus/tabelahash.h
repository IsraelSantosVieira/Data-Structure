/*
 * Trabalho Final de Estrutura de Dados
 * 
 * Por: Israel Santos Vieira(201820268)
 *      Gustavo Costa Daguer(201910924)
 *      Mateus de Oliveira Peternelli(201820283) 
 * UFLA - 2019/2
 *
 * Arquivo de cabeçalho: tabelahash.h
 * 
 */
#ifndef TABELAHASH_H
#define TABELAHASH_H
#include "noh.h"
#include "Streaming.h"
typedef int Dado;
using namespace std;

class tabelaHash {
  private:
  noh** jogadores;
  int capacidade;
  int tamanho;
  public:
  
  // Construtor da Tabela Hash
  tabelaHash(int cap = 40);
  // Destrutor da Tabela Hash
  ~tabelaHash();
  void insere(Dado chave, Dado habilidadeJogador, Dado idadeJogador, Dado precioso);
  bool existe(Dado chave);
  void remover(Dado chave);
  void busca(Dado chave);
  void percorre();
  inline bool cheia();
  int meuTamanho();
  Dado myPrecious(Dado chave);
  int funcaoPreciosidade(Dado habilidadeJogador, Dado idadeJogador);
};

#endif /* TABELAHASH_H */
