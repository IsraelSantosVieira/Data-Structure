 * Trabalho Final de Estrutura de Dados
 * 
 * Por: Israel Santos Vieira(201820268)
 *      Gustavo Costa Daguer(201910924)
 *      Mateus de Oliveira Peternelli(201820283) 
 * UFLA - 2019/2

* => Bibliotecas utilizadas para auxiliar no uso do
serial e para facilitar a manipulação do Keypad.

* Bibliotecas:
* - Keypad.h
* - Streaming.h