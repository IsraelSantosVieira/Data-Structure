/*
 * Trabalho Final de Estrutura de Dados
 * 
 * Por: Israel Santos Vieira(201820268)
 *      Gustavo Costa Daguer(201910924)
 *      Mateus de Oliveira Peternelli(201820283) 
 * UFLA - 2019/2
 *
 * Arquivo de cabeçalho: noh.h
 * 
 */

#ifndef NOH_H
#define NOH_H
#include "Streaming.h"
typedef int Dado;
using namespace std;

class noh {
  friend class tabelaHash;
  private:
  Dado numeroCamisa; //string chave;
  Dado habilidade; //string valor;
  Dado idade;
  Dado preciosidade;
  noh* proximo = nullptr;
  public:
  noh(Dado chave, Dado habilidadeJogador, Dado idadeJogador, Dado precioso);
};

#endif /* NOH_H */
