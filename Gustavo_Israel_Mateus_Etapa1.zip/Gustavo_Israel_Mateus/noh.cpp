/*
 * Trabalho Final de Estrutura de Dados
 * 
 * Por: Israel Santos Vieira(201820268)
 *      Gustavo Costa Daguer(201910924)
 *      Mateus de Oliveira Peternelli(201820283)
 * UFLA - 2019/2
 *
 * Implementação do construtor.
 * 
 */

#include "noh.h"
#include "Streaming.h"
typedef int Dado;

using namespace std;

//Construtor
noh::noh(Dado chave, Dado habilidadeJogador, Dado idadeJogador, Dado precioso) {
    numeroCamisa = chave;
    habilidade = habilidadeJogador;
    idade = idadeJogador;
    preciosidade = precioso;
}
