/*
 * Trabalho Final de Estrutura de Dados
 * 
 * Por: Israel Santos Vieira(201820268)
 *      Gustavo Costa Daguer(201910924)
 *      Mateus de Oliveira Peternelli(201820283) 
 * UFLA - 2019/2
 *
 * Arquivo de implementação do teclado 4x4.
 * 
 */

#include <Keypad.h>
const byte ROWS = 4;
const byte COLS = 4;
char keys[ROWS][COLS] = {
 {'1','2','3','A'},
 {'4','5','6','B'},
 {'7','8','9','C'},
 {'*','0','#','D'}
};
byte rowPins[ROWS] = {9,8,7,6}; //Linhas(pinos de 9 ao 6)
byte colPins[COLS] = {5,4,3,2}; //Colunas (pinos de 5 a 2)
Keypad keypad = Keypad( makeKeymap(keys), rowPins, colPins, ROWS, COLS );

String GetNumber(){
   String num;
   char key = keypad.getKey();
   while(key != '#'){
    switch (key){
     case NO_KEY:
      break;

     case '0': case '1': case '2': case '3': case '4':
     case '5': case '6': case '7': case '8': case '9':

      num = num +key;
      break;

     case '*':
        num = "";
        break;
     // Caso o usuário aperte a letra:
     case 'A':
        num = "101"; // Inserir
        break;
     case 'B':
        num = "102"; // Remover
        break;
     case 'C':
        num = "103"; // Buscar
        break;
     case 'D':
        num = "104"; //Ordenar
        break;
    }
    key = keypad.getKey();      
   }
   return num;
   
}
